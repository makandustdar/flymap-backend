from django.contrib import admin

from .models import FlyingSite, ForecastCache


@admin.register(FlyingSite)
class FlyingSiteAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "name",
        "lat",
        "lon",
        "wind_max_kmh",
        "gust_max_kmh",
        "timezone",
        "is_active",
        "updated_at",
    )
    list_filter = ("is_active", "timezone")
    search_fields = ("id", "name", "notes")
    readonly_fields = ("created_at", "updated_at")


@admin.register(ForecastCache)
class ForecastCacheAdmin(admin.ModelAdmin):
    list_display = (
        "site",
        "model",
        "source",
        "model_elevation_m",
        "fetched_at",
    )
    list_filter = ("model", "source")
    search_fields = ("site__id", "site__name")
    readonly_fields = ("fetched_at",)
